{{/*
Flavor defaults written by hack/package-helm.sh for datasance.
*/}}
{{- define "iofog-operator.crdGroup" -}}datasance.com{{- end }}
{{- define "iofog-operator.controlPlaneName" -}}pot{{- end }}
{{- define "iofog-operator.operatorImageDefault" -}}ghcr.io/datasance/operator:3.9.2-rc.2{{- end }}
